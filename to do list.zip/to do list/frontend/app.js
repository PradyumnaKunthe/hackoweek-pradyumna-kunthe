const API_URL = 'http://localhost:3000/api/tasks';

// DOM Elements
const taskInput = document.getElementById('task-input');
const addBtn = document.getElementById('add-btn');
const taskList = document.getElementById('task-list');
const loader = document.getElementById('loader');
const taskStats = document.getElementById('task-stats');
const filterBtns = document.querySelectorAll('.filter-btn');
const themeToggle = document.getElementById('theme-toggle');
const aiSuggestionsPanel = document.getElementById('ai-suggestions');

// State
let tasks = [];
let currentFilter = 'all';

// ==========================================
// AI / Smart Features
// ==========================================

const AI_SUGGESTIONS_DB = {
    'study': ['Study focus for 2 hours', 'Read next chapter', 'Complete course assignment'],
    'gym': ['Leg day workout', 'Cardio 30 mins', 'Upper body strength'],
    'workout': ['Go for a run', 'Yoga session', 'Pushups & Pullups'],
    'buy': ['Buy groceries', 'Order gift', 'Buy household supplies'],
    'call': ['Call mom', 'Call client back', 'Schedule meeting'],
    'email': ['Reply to manager', 'Send weekly update', 'Inbox zero'],
    'pay': ['Pay electric bill', 'Pay internet bill', 'Pay rent'],
    'clean': ['Clean the kitchen', 'Vacuum the house', 'Do laundry']
};

const CATEGORY_KEYWORDS = {
    'Work': ['meeting', 'client', 'project', 'boss', 'email', 'report', 'presentation'],
    'Personal': ['buy', 'call', 'gift', 'pay', 'mom', 'dad', 'family', 'clean'],
    'Health': ['gym', 'workout', 'run', 'yoga', 'medicine', 'doctor', 'water', 'sleep']
};

const PRIORITY_KEYWORDS = {
    'High': ['urgent', 'asap', 'important', 'tomorrow', 'today', 'emergency'],
    'Low': ['later', 'eventually', 'someday', 'whenever']
    // Default is Medium
};

function analyzeIntent(text) {
    text = text.toLowerCase();
    
    // Suggestion logic
    const suggestions = [];
    for (const [key, options] of Object.entries(AI_SUGGESTIONS_DB)) {
        if (text.includes(key)) {
            suggestions.push(...options);
        }
    }

    // Category logic
    let category = 'General';
    for (const [cat, keywords] of Object.entries(CATEGORY_KEYWORDS)) {
        if (keywords.some(kw => text.includes(kw))) {
            category = cat;
            break;
        }
    }

    // Priority logic
    let priority = 'Medium';
    for (const [pri, keywords] of Object.entries(PRIORITY_KEYWORDS)) {
        if (keywords.some(kw => text.includes(kw))) {
            priority = pri;
            break;
        }
    }

    return { 
        suggestions: suggestions.slice(0, 3), // max 3 suggestions 
        category, 
        priority 
    };
}

// Handle AI Suggestions UI
taskInput.addEventListener('input', (e) => {
    const val = e.target.value.trim();
    if (val.length < 3) {
        aiSuggestionsPanel.classList.add('hidden');
        return;
    }

    const { suggestions } = analyzeIntent(val);
    
    if (suggestions.length > 0) {
        aiSuggestionsPanel.innerHTML = suggestions.map(s => 
            `<div class="suggestion-chip" onclick="applySuggestion('${s}')">
                <i class="fa-solid fa-sparkles"></i> ${s}
            </div>`
        ).join('');
        aiSuggestionsPanel.classList.remove('hidden');
    } else {
        aiSuggestionsPanel.classList.add('hidden');
    }
});

window.applySuggestion = function(text) {
    taskInput.value = text;
    aiSuggestionsPanel.classList.add('hidden');
    taskInput.focus();
};

// ==========================================
// Core Functionality
// ==========================================

// Fetch tasks
async function fetchTasks() {
    showLoader();
    try {
        const response = await fetch(API_URL);
        tasks = await response.json();
        renderTasks();
    } catch (error) {
        console.error('Failed to fetch tasks', error);
        // Fallback to local storage if API fails
        const localTasks = localStorage.getItem('flowtasks_offline');
        if (localTasks) {
            tasks = JSON.parse(localTasks);
            renderTasks();
        }
    }
    hideLoader();
}

// Add task
async function addTask() {
    const text = taskInput.value.trim();
    if (!text) return;

    // AI Prediction for Category and Priority
    const { category, priority } = analyzeIntent(text);

    const newTaskData = { text, category, priority };

    taskInput.value = '';
    aiSuggestionsPanel.classList.add('hidden');
    
    // Optimistic UI update
    const tempId = 'temp-' + Date.now();
    const tempTask = { id: tempId, ...newTaskData, completed: false, createdAt: new Date() };
    tasks.unshift(tempTask);
    renderTasks();

    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(newTaskData)
        });
        const savedTask = await response.json();
        
        // Replace temp task with real task
        tasks = tasks.map(t => t.id === tempId ? savedTask : t);
        updateOfflineStorage();
    } catch (error) {
        console.error('Failed to save task', error);
        alert('Failed to save task to server. Ensure backend is running.');
    }
    renderTasks();
}

// Toggle Task Completion
async function toggleTask(id) {
    const task = tasks.find(t => t.id === id);
    if (!task) return;

    const newStatus = !task.completed;
    
    // Optimistic UI
    task.completed = newStatus;
    renderTasks();

    try {
        await fetch(`${API_URL}/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ completed: newStatus })
        });
        updateOfflineStorage();
    } catch (error) {
        console.error('Failed to update task', error);
        task.completed = !newStatus; // Revert
        renderTasks();
    }
}

// Delete Task
async function deleteTask(id) {
    // Optimistic UI
    const previousTasks = [...tasks];
    tasks = tasks.filter(t => t.id !== id);
    renderTasks();

    try {
        await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
        updateOfflineStorage();
    } catch (error) {
        console.error('Failed to delete task', error);
        tasks = previousTasks; // Revert
        renderTasks();
    }
}

function updateOfflineStorage() {
    localStorage.setItem('flowtasks_offline', JSON.stringify(tasks));
}

// ==========================================
// UI Rendering
// ==========================================

function renderTasks() {
    taskList.innerHTML = '';
    
    const filteredTasks = tasks.filter(t => {
        if (currentFilter === 'pending') return !t.completed;
        if (currentFilter === 'completed') return t.completed;
        return true; // 'all'
    });

    taskStats.textContent = `${filteredTasks.length} task${filteredTasks.length !== 1 ? 's' : ''}`;

    if (filteredTasks.length === 0) {
        taskList.innerHTML = `<div style="text-align:center; color:var(--text-muted); padding: 2rem 0;">No tasks found.</div>`;
        taskList.classList.remove('hidden');
        return;
    }

    filteredTasks.forEach(task => {
        const li = document.createElement('li');
        li.className = `task-item ${task.completed ? 'completed' : ''}`;
        
        const catClass = `badge-cat-${task.category.toLowerCase()}`;
        const priClass = `badge-priority-${task.priority.toLowerCase()}`;

        li.innerHTML = `
            <input type="checkbox" class="task-checkbox" ${task.completed ? 'checked' : ''} onchange="toggleTask('${task.id}')">
            <div class="task-content">
                <span class="task-text">${escapeHTML(task.text)}</span>
                <div class="task-meta">
                    <span class="badge ${catClass}">${task.category}</span>
                    <span class="badge ${priClass}">${task.priority}</span>
                </div>
            </div>
            <div class="task-actions">
                <button class="action-btn del" onclick="deleteTask('${task.id}')" aria-label="Delete Task">
                    <i class="fa-solid fa-trash"></i>
                </button>
            </div>
        `;
        taskList.appendChild(li);
    });

    taskList.classList.remove('hidden');
}

function showLoader() {
    loader.classList.remove('hidden');
    taskList.classList.add('hidden');
}

function hideLoader() {
    loader.classList.add('hidden');
}

function escapeHTML(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

// ==========================================
// Event Listeners
// ==========================================

addBtn.addEventListener('click', addTask);
taskInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') addTask();
});

filterBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
        filterBtns.forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        currentFilter = e.target.dataset.filter;
        renderTasks();
    });
});

// Theme Toggle
themeToggle.addEventListener('click', () => {
    const root = document.documentElement;
    const isDark = root.getAttribute('data-theme') === 'dark';
    
    if (isDark) {
        root.removeAttribute('data-theme');
        themeToggle.innerHTML = '<i class="fa-solid fa-moon"></i>';
        localStorage.setItem('theme', 'light');
    } else {
        root.setAttribute('data-theme', 'dark');
        themeToggle.innerHTML = '<i class="fa-solid fa-sun"></i>';
        localStorage.setItem('theme', 'dark');
    }
});

// Init
function init() {
    // Load theme
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        document.documentElement.setAttribute('data-theme', 'dark');
        themeToggle.innerHTML = '<i class="fa-solid fa-sun"></i>';
    }

    fetchTasks();
}

init();
