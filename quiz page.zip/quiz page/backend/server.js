const express = require('express');
const cors = require('cors');
const fs = require('fs').promises;
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data', 'questions.json');

app.use(cors());
app.use(express.json());

// Serve frontend static files
app.use(express.static(path.join(__dirname, '../frontend')));

// Utility to read questions
async function getQuestions() {
    try {
        const data = await fs.readFile(DATA_FILE, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading data file:', error);
        return [];
    }
}

// Utility to shuffle an array
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

// API: Get questions (randomized, optional category filter)
app.get('/api/questions', async (req, res) => {
    try {
        let questions = await getQuestions();
        const category = req.query.category;
        
        if (category && category !== 'all') {
            questions = questions.filter(q => q.category.toLowerCase() === category.toLowerCase());
        }

        // Shuffle questions
        questions = shuffleArray(questions);

        // Remove correctAnswer from the payload so client can't cheat easily
        // Wait, the client needs the correctAnswer to provide instant feedback if we don't submit per question.
        // The requirements say: "Instant feedback after selecting answer".
        // The requirements also say: "POST /submit -> calculate and return score".
        // If the server calculates the final score, the client shouldn't cheat, but to give instant feedback without calling the server for every single question, the client needs to know the correct answer.
        // For security in a real app, you'd verify per question, but here we can send it or verify on server.
        // Let's send the correct answer for the instant feedback requirement, and the server will just recalculate the score strictly on POST /submit anyway based on the submitted answers.
        
        res.json(questions.slice(0, 10)); // return up to 10 questions
    } catch (err) {
        res.status(500).json({ error: 'Failed to fetch questions' });
    }
});

// API: Submit quiz and calculate score
app.post('/api/submit', async (req, res) => {
    try {
        // req.body.answers format: [{ id: "q1", answer: "Option A", timeRemaining: 15 }]
        const userAnswers = req.body.answers || [];
        const questions = await getQuestions();
        
        let score = 0;
        let correctCount = 0;
        const total = userAnswers.length;

        for (const userAns of userAnswers) {
            const question = questions.find(q => q.id === userAns.id);
            if (!question) continue;

            if (userAns.answer === question.correctAnswer) {
                correctCount++;
                let points = 100;
                
                // Bonus points for fast answers
                // Max time is 20 seconds. 
                // bonus = timeRemaining * 5
                const timeBonus = (userAns.timeRemaining || 0) * 5;
                points += timeBonus;
                
                score += points;
            }
        }

        res.json({ score, correctCount, total, message: getPerformanceMessage(correctCount, total) });
    } catch (err) {
        res.status(500).json({ error: 'Failed to submit quiz' });
    }
});

function getPerformanceMessage(correctCount, total) {
    const percentage = correctCount / total;
    if (percentage >= 0.8) return "Excellent!";
    if (percentage >= 0.5) return "Good!";
    return "Try Again!";
}

// API: Add a new question
app.post('/api/add-question', async (req, res) => {
    try {
        const { question, options, correctAnswer, category } = req.body;
        if (!question || !options || !correctAnswer || !category) {
            return res.status(400).json({ error: 'Missing required fields' });
        }

        const questions = await getQuestions();
        const newQuestion = {
            id: `q${Date.now()}`,
            question,
            options,
            correctAnswer,
            category
        };

        questions.push(newQuestion);
        await fs.writeFile(DATA_FILE, JSON.stringify(questions, null, 2));

        res.status(201).json({ message: 'Question added successfully', question: newQuestion });
    } catch (err) {
        res.status(500).json({ error: 'Failed to add question' });
    }
});

// Fallback to index.html for SPA routes (if any)
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
